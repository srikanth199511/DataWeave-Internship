1.I have done the assignment in ipython notebook.
2.For opening this notebook, you need to have Jupyter setup/ Anaconda Navigator. If you dont have it, open in online ipython tool(Google it).
3.I have also uploaded the PDF of the file. Just in case you need one.

Thank You.
